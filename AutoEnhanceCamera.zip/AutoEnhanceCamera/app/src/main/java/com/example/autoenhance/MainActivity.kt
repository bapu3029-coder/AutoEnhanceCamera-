package com.example.autoenhance

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var result: ImageView
    private lateinit var status: TextView
    private lateinit var shutter: Button
    private lateinit var retake: Button
    private var capture: ImageCapture? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else toast("Camera permission is required")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        result = findViewById(R.id.result)
        status = findViewById(R.id.status)
        shutter = findViewById(R.id.shutter)
        retake = findViewById(R.id.retake)
        shutter.setOnClickListener { shoot() }
        retake.setOnClickListener {
            result.visibility = View.GONE
            retake.visibility = View.GONE
            status.visibility = View.GONE
            shutter.visibility = View.VISIBLE
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            askCamera.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun shoot() {
        val cap = capture ?: return
        shutter.isEnabled = false
        showStatus("Capturing…")
        cap.takePicture(worker, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = image.toBitmap()
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    runOnUiThread { showStatus("Enhancing…") }
                    val out = Enhancer.enhance(bmp)
                    val saved = saveToGallery(out)
                    runOnUiThread {
                        result.setImageBitmap(out)
                        result.visibility = View.VISIBLE
                        shutter.visibility = View.GONE
                        shutter.isEnabled = true
                        retake.visibility = View.VISIBLE
                        showStatus(if (saved) "Saved to Pictures/AutoEnhance" else "Could not save the photo")
                    }
                } catch (t: Throwable) {
                    runOnUiThread { shutter.isEnabled = true; showStatus("Error: ${t.message}") }
                } finally {
                    image.close()
                }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread { shutter.isEnabled = true; showStatus("Capture failed: ${e.message}") }
            }
        })
    }

    private fun saveToGallery(bmp: Bitmap): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Enhanced_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoEnhance")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return true
    }

    private fun showStatus(t: String) { status.text = t; status.visibility = View.VISIBLE }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}

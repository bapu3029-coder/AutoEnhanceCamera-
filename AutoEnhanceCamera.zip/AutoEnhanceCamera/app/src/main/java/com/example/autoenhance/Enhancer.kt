package com.example.autoenhance

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Denoise -> auto levels + DSLR-style color grade -> sharpen. */
object Enhancer {
    private const val MAX_SIDE = 4000

    fun enhance(input: Bitmap): Bitmap {
        var bmp = input
        val side = max(bmp.width, bmp.height)
        if (side > MAX_SIDE) {
            val s = MAX_SIDE.toFloat() / side
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
        }
        val w = bmp.width
        val h = bmp.height
        var px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        px = denoise(px, w, h)
        grade(px)
        px = sharpen(px, w, h)
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun lum(c: Int) = (77 * (c shr 16 and 255) + 150 * (c shr 8 and 255) + 29 * (c and 255)) shr 8

    // Edge-preserving 3x3 blur: only neighbours with similar brightness are averaged.
    private fun denoise(p: IntArray, w: Int, h: Int): IntArray {
        val l = IntArray(p.size) { lum(p[it]) }
        val o = p.copyOf()
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                var r = (p[i] shr 16 and 255) * 6
                var g = (p[i] shr 8 and 255) * 6
                var b = (p[i] and 255) * 6
                var n = 6
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val j = i + dy * w + dx
                    if (abs(l[j] - l[i]) < 18) {
                        r += p[j] shr 16 and 255
                        g += p[j] shr 8 and 255
                        b += p[j] and 255
                        n++
                    }
                }
                o[i] = (0xFF shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        return o
    }

    // Auto levels, brightness balance, soft S-curve, vibrance and a slight warm tone.
    private fun grade(p: IntArray) {
        val hist = IntArray(256)
        for (c in p) hist[lum(c)]++
        val clip = p.size * 0.005
        var lo = 0
        var acc = 0
        while (lo < 255) { acc += hist[lo]; if (acc > clip) break; lo++ }
        var hi = 255
        acc = 0
        while (hi > 0) { acc += hist[hi]; if (acc > clip) break; hi-- }
        if (hi - lo < 20) { lo = 0; hi = 255 }
        val span = (hi - lo).toFloat()
        var sum = 0.0
        for (v in 0..255) sum += hist[v] * ((v - lo) / span).coerceIn(0f, 1f)
        val mean = max(sum / p.size, 0.03)
        val gamma = (ln(0.46) / ln(mean)).coerceIn(0.55, 1.25).toFloat()
        val lut = FloatArray(256) { v ->
            val x = ((v - lo) / span).coerceIn(0f, 1f).pow(gamma)
            val s = x * x * (3 - 2 * x)
            (x * 0.75f + s * 0.25f) * 255f
        }
        for (i in p.indices) {
            val c = p[i]
            var r = lut[c shr 16 and 255]
            var g = lut[c shr 8 and 255]
            var b = lut[c and 255]
            val l = 0.299f * r + 0.587f * g + 0.114f * b
            val k = 1f + 0.25f * (1f - (max(r, max(g, b)) - min(r, min(g, b))) / 255f)
            r = (l + (r - l) * k) * 1.02f
            g = l + (g - l) * k
            b = (l + (b - l) * k) * 0.98f
            p[i] = (0xFF shl 24) or (r.toInt().coerceIn(0, 255) shl 16) or
                (g.toInt().coerceIn(0, 255) shl 8) or b.toInt().coerceIn(0, 255)
        }
    }

    private fun sharpen(p: IntArray, w: Int, h: Int): IntArray {
        val o = p.copyOf()
        val a = 0.45f
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                var out = 0xFF shl 24
                var s = 16
                while (s >= 0) {
                    val v = (1 + 4 * a) * (p[i] shr s and 255) -
                        a * ((p[i - 1] shr s and 255) + (p[i + 1] shr s and 255) +
                            (p[i - w] shr s and 255) + (p[i + w] shr s and 255))
                    out = out or (v.toInt().coerceIn(0, 255) shl s)
                    s -= 8
                }
                o[i] = out
            }
        }
        return o
    }
}
